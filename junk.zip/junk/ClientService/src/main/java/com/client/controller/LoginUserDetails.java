package com.client.controller;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient("login-service")
interface LoginUserDetails {
	
	@RequestMapping(value="/getLoginDetailsUsingFeign",method=RequestMethod.GET)
	String getLoginDetailsUsingFeign();

}
