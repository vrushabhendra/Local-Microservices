package com.client.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController	
public class ClientForServicesController {
	
	@Autowired
	DiscoveryClient objDiscoveryClient;
	
	@RequestMapping("/getAllServiceInstances")
	private String getAllServiceInstances(){
		
		List<ServiceInstance> instances = objDiscoveryClient.getInstances("LOGIN-SERVICE");
		String strInstanceDetails = "Nothing";
		if(null!=instances && instances.size()>0){
			strInstanceDetails = "Host: "+instances.get(0).getHost()+" and Port: "+instances.get(0).getPort() + " And the size of instaces is : "+instances.size();
		}
		return strInstanceDetails;
	}

}
