package com.client;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

@EnableDiscoveryClient
@EnableFeignClients
@EnableZuulProxy
@SpringBootApplication
public class ClientServiceApplication {

	@Bean
	CommandLineRunner cmdRunner(DiscoveryClient objDiscoveryClient) {
		return args -> {
			List<ServiceInstance> lstInstanceInfo = objDiscoveryClient.getInstances("login-service");
			lstInstanceInfo.forEach(i -> System.out.println(i.getHost() + " " + i.getPort()));
		};
	}

	public static void main(String[] args) {
		SpringApplication.run(ClientServiceApplication.class, args);
	}
}
