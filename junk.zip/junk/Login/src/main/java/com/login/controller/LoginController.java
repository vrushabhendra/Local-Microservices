package com.login.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.login.entity.LoginUserEntity;

@RestController
public class LoginController {

	@RequestMapping("/getLoginUser")
	LoginUserEntity getLoginUser() {

		LoginUserEntity objLoginUserEntity = new LoginUserEntity("vrush", "****");
		return objLoginUserEntity;
	}
}
